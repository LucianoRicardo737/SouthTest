import React, {useState, useEffect} from 'react'

import { useAccountContext } from '../../context/AccountProvider'
import { useAppContext } from '../../context/AppProvider'

const AddNewAccount = () => {
  const {getInLocalTheLocalAccounts,localSet, setDataAccount} =useAppContext()

  const {typeAccountSelected,setViewNewAccountOrDetailAccount, dataFormForNewAccount, setDataFormForNewAccount} = useAccountContext()

  const addAccountStyle = {
    cont:{
      border: '1px solid rgb(237,237,238)',
      padding: '20px',
      borderRadius: '5px'
    }
  }
  
  const closeThisView = () => {
    setViewNewAccountOrDetailAccount(false)
  }
  
  const useField = ({name, label,type}) => {

    useEffect(()=>{
      setValue('')
    },[typeAccountSelected])

    const [value, setValue] = useState('')

    const handleChange = (e) => {
      setValue(e.target.value)
      setDataFormForNewAccount({ ...dataFormForNewAccount, [name]: value})
    }
    return(
      <div className="field">
        <label>{label}</label>
        <input 
          onChange={handleChange}
          value={value}
          type={type} 
          name={name} />
      </div>
    )
  }
  const returnBankName = useField({
    label:'Bank Name',
    name:'bankName',
    type:'text'
  })
  const returnBankAddress = useField({
    label:'Bank Address',
    name:'bankAddress',
    type:'text'
  })
  const returnAccountNumber = useField({
    label:'Account Number',
    name:'accountNumber',
    type:'number'
  })
  const returnTypeCoin = useField({
    label:'Type Coin',
    name:'typeCoin',
    type:'text'
  })
  const returnSwiftNumber = useField({
    label:'Swift Number',
    name:'swiftNumber',
    type:'text'
  })
  const returnPersonalAddress = useField({
    label:'Personal Address',
    name:'beneficiaryAddress',
    type:'text'
  })

  const submitNewAccountForm = (e) => {
    e.preventDefault()
    const addDataToLocalStorage = () =>{
      let data = getInLocalTheLocalAccounts()
      let newObject = [...data,dataFormForNewAccount]
      return newObject
    }
    localSet('accountsData', addDataToLocalStorage())
    setDataAccount(getInLocalTheLocalAccounts())
  }
  
  return (
    <div style={addAccountStyle.cont} className='ui doubling stackable'>
      <form className="ui mini form" onSubmit={(e)=>submitNewAccountForm(e)}>
        <div className="three fields">
          {returnBankName }
          {returnBankAddress}
          {returnAccountNumber}
        </div>
        <div className="two fields">
          {typeAccountSelected!=='local' ? <>
            {returnTypeCoin}
            {returnSwiftNumber} </> : null
          }
          {returnPersonalAddress}
        </div>
        <button type='submit' className="ui button">Submit</button>
        <span onClick={()=>closeThisView()} className="ui button">Cancel</span>
      </form>
    </div>
  )
}

export default AddNewAccount
