import React, {useContext, useState, useEffect} from 'react'
import { useAppContext } from './AppProvider'

const AccountContext = React.createContext()

const useAccountContext = () => { 
  return useContext(AccountContext)
}

const AccountProvider = ({ children }) => {

  let {userData, accountsData, setUserData, localSet} = useAppContext()
  const [typeAccountSelected, setTypeAccountSelected] = useState('local')

  const initialDataAccoutn = {
    beneficiary: `${userData.name} ${userData.lastname}`,
    beneficiaryAddress:'',
    accountNumber:'',
    bankName:'',
    bankAddress:'',
    typeCoin:'',
    swiftNumber:'',
    type:typeAccountSelected
  }

  const [viewNewAccountOrDetailAccount, setViewNewAccountOrDetailAccount] = useState(false)
  const [viewDetailAccount, setViewDetailAccount] = useState(false)
  const [viewPaymeHere, setViewPaymeHere] = useState(false)


  const [dataAccount, setDataAccount] = useState (initialDataAccoutn) 
  const [paymeHereAccountNumber,setPaymeHereAccountNumber]=useState('')
  const [dataFormForNewAccount, setDataFormForNewAccount] = useState(initialDataAccoutn)

  function setData (e) {
    const accData = accountsData?.filter(res => { return res.accountNumber === e.target.id })
    setDataAccount(accData[0])
    setViewNewAccountOrDetailAccount(false)
    setViewPaymeHere(false)
    setViewDetailAccount(true)
  }

  function seePaymetHere(e){
    setViewNewAccountOrDetailAccount(false)
    setViewDetailAccount(false)
    setViewPaymeHere(true)
    setPaymeHereAccountNumber(e.target.id)
  }

  function closePaymentHere(){
    setViewPaymeHere(false)
  }

  useEffect(()=>{
    try {
      setDataFormForNewAccount(initialDataAccoutn)
    } catch (error) {
      console.log(error)
    }
  },[typeAccountSelected])
  
  function viewNewAccount (){
    setViewPaymeHere(false)
    setViewDetailAccount(false)
    setViewNewAccountOrDetailAccount(true)
  }


  function changeTypeAccount(action) {
    const localSelector = document.querySelector('.local')
    const internationalSelector = document.querySelector('.international')
    setViewDetailAccount(false)
    setViewPaymeHere(false)
    if(action === 'local'){
      setTypeAccountSelected('local')
      internationalSelector.classList.remove('active')
      localSelector.classList.add('active')
    } else {
      setTypeAccountSelected('international')
      localSelector.classList.remove('active')
      internationalSelector.classList.add('active')
    }
  }

  function salaryNotAssigned(){
    const maxSalaryToAssigned = userData.depositAccounts?.reduce((total, num)=>{return total - num.pay
    }, userData.monthlySalary)
    let result = maxSalaryToAssigned 
    if(salaryAssignedToThisCount()){
      result = result + salaryAssignedToThisCount()
    }
    return result.toString()
  }

  function salaryAssignedToThisCount(){
    const totalyAssignedToThisAccount = userData.depositAccounts?.filter(res=>{
      return res.accountNumber === paymeHereAccountNumber
    }).map(res=>{return res.pay})
    return totalyAssignedToThisAccount[0]
  }
  
  function isAssigned(value){
    const totalyAssignedToThisAccount = userData.depositAccounts?.filter(res=>{
      return res.accountNumber === value
    }).map(res=>{return res.pay})
    if(totalyAssignedToThisAccount[0]){
      return true
    } else {
      return false
    }
  }

  function maxTwoSelected(){
    if(userData.depositAccounts.length < 2){
      return true
    } else { 
      return false
    }
  }
 
  function unselectPayment(e){
    let data = userData.depositAccounts.filter(res=>{
      return res.accountNumber !== e.target.id
    })
    let newUserData = {...userData, depositAccounts:data}
    setUserData(newUserData)
    localSet('userData', newUserData)
  }

  const [dataSelectedNewPayment, setDataSelectedNewPayment] = useState(0)

  const handlerSelectedPaymentAccount = (e) => {
    setDataSelectedNewPayment(e.target.value)
  }

  function sumbitSelectNewPaymentAccount(){
    const initialSelectedNewPaymentValue = {
      accountNumber: paymeHereAccountNumber,
      typeAccount: typeAccountSelected,
      pay: dataSelectedNewPayment
    }
    if(!maxTwoSelected())return console.log('Can`t select more two accounts')
    let newUserData = {...userData, depositAccounts:[...userData.depositAccounts, initialSelectedNewPaymentValue]}
    setUserData(newUserData)
    localSet('userData', newUserData)
  }

  return (
    <AccountContext.Provider
      value={{
        setData,
        dataAccount,setDataAccount,
        viewNewAccountOrDetailAccount,setViewNewAccountOrDetailAccount,
        typeAccountSelected, setTypeAccountSelected,
        dataFormForNewAccount,setDataFormForNewAccount,
        viewDetailAccount, setViewDetailAccount,
        paymeHereAccountNumber,seePaymetHere,
        salaryNotAssigned,salaryAssignedToThisCount,
        isAssigned,maxTwoSelected,
        viewNewAccount,
        changeTypeAccount,
        unselectPayment,
        viewPaymeHere,
        closePaymentHere,
        sumbitSelectNewPaymentAccount,
        handlerSelectedPaymentAccount
      }}
    > 
      {children}
    </AccountContext.Provider>
  )
}

export { AccountProvider, useAccountContext }