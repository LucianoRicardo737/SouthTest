import React, { useState, useContext, useEffect } from 'react'
import { initialUserData, initialAccountsData } from '../db/initialData_db'

const AppContext = React.createContext()

const useAppContext = () => {
  return useContext(AppContext)
}

const AppProvider = ({ children }) => {

  const localSet = (name, data) => localStorage.setItem(name, JSON.stringify(data))
  const localGet = name => JSON.parse(localStorage.getItem(name))

  function getInLocalTheUserData () {
    if(localGet('userData')===null){
      return setInLocalTheUserData()
    } else {
      return localGet('userData')
    }
  }

  function getInLocalTheLocalAccounts () {
    if(localGet('accountsData')===null){
      return []
    } else {
      return localGet('accountsData')
    }
  }

  const setInLocalTheUserData = () =>  localSet('userData', initialUserData)
  const setInLocalTheLocalAccounts = () => localSet('accountsData', initialAccountsData)


  const [accountsData, setDataAccount] = useState(getInLocalTheLocalAccounts)

  const [userData, setUserData]=useState(getInLocalTheUserData)



  useEffect(() => {
    try {
      setUserData(getInLocalTheUserData())
      setDataAccount(getInLocalTheLocalAccounts())
    } catch (error) {
      console.log(error)
    }
  }, [])

  

  
  return (
    <AppContext.Provider
      value={{
        initialUserData,
        userData,
        setUserData,
        initialAccountsData,

        localSet,localGet,

        accountsData, setDataAccount,

        getInLocalTheUserData,getInLocalTheLocalAccounts,
        setInLocalTheUserData,setInLocalTheLocalAccounts,
        
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export { AppProvider, useAppContext }
